import Funciones.Funciones;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Analizando ADN");

        ArrayList<String> arraydnaList = new ArrayList<String>();     //Creo un arreglo, que es donde vamos a ir guardando los strings que ingresa el usuario.
        for (int i = 0; i < 6; i++) {                           //El ciclo for se ejecuta seis veces, que es la cantidad de strings que tenemos que pedirle al usuario.
            Funciones.dnaIntro(arraydnaList);                  //Llamamos a la funcion "dnaIntro()" pasandole el array.
        }

        ArrayList<ArrayList<String>> arrayMatrixdna = new ArrayList<ArrayList<String>>();  //Creo la matriz.


        System.out.println();
        if (Funciones.isMutant(arraydnaList)) {            //Aca, depende del resultado de la matriz, imprime si es mutante o no.
            System.out.println();
            System.out.println("MUTANTE");
        } else {
            System.out.println();
            System.out.println("NO MUTANTE");
        }
    }
}

//Casos de prueba:
// Mutante = [acgttc,catcgt,aaagcg,tgaaat,catttt,tgatct]
// NO Mutante = [aaagcg,tagctt,ttagcc,gatggc,tgccaa,ccagtt]