package Funciones;

import java.util.ArrayList;
import java.util.Scanner;

public class Funciones {
    static Scanner input = new Scanner(System.in);
    String dna;

    public static ArrayList<String> dnaIntro(ArrayList<String> arraydnaList) {         //La función "dnaIntro()" recibe el array y va a ir almacenando los strings ingresados por el usuario.
        while (true) {
            System.out.println("Ingrese cadean de ADN: ");                           //Pide el string y luego verifica llamando a dos funciones más: "validator6()" y "validatorChar()".
            String dna = input.next().toUpperCase();
            if (validator6(dna) && validatorChar(dna)) {
                arraydnaList.add(dna);                                              //Una vez que se cumple la condición, se agrega el str al array.
                return arraydnaList;                                               //Y se retorna el arraylist al programa principal.
            } else {
                System.out.println("ERROR de ADN. Intente nuevamente.");          //Si no se cumple, vuelve a pedir que el usuario ingrese.
            }
        }
    }

    public static boolean validator6(String dna) {                   //"validator6()" lo que hace es ver si la longitud del str es de 6.
        if (dna.length() == 6) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean validatorChar(String dna) {                // "validatorChar" lo que hace es, con un ciclo for,recorretodo el str para ver que las letras ingresadas solo sean A,C,G,T.
        for (int i = 0; i < dna.length(); i++) {
            if (dna.charAt(i) != 'A' && dna.charAt(i) != 'T' && dna.charAt(i) != 'C' && dna.charAt(i) != 'G') {
                return false;
            }
        }
        return true;
    }

    public static boolean isMutant(ArrayList<String> arraydnaList) {           //La función "isMutant()" lo primero que hace es recibir el arreglo de strings y colocarlo en una matriz 6x6.
        int mutant = 0;

        ArrayList<ArrayList<String>> arrayMatrixdna = new ArrayList<ArrayList<String>>();

        for (String dna : arraydnaList) {
            ArrayList<String> row = new ArrayList<>();
            for (int i = 0; i < dna.length(); i++){
                row.add(String.valueOf(dna.charAt(i)));
            }
            arrayMatrixdna.add(row);                                   //Lo que hago aca el poner cada str del array en cada fila de la matriz.
        }

        for (ArrayList<String> row : arrayMatrixdna) {               //Imprime la matriz en formato matriz, con los valores ingresados por el usuario anteriormente.
            for (String element : row) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
                                                           //Aca cada vez que encuentre en una subfunción una secuencia de 4 letras iguales, va a ir sumando 1 a la variable mutant.
        if (horizontal(arrayMatrixdna)) {
            mutant++;
        }
        if (vertical(arrayMatrixdna)) {
            mutant++;
        }
        if (diagonal(arrayMatrixdna)) {
            mutant++;
        }

        return mutant >= 2;                      //Finalmente compara, si se encuentran 2 o más secuencias de 4 letras iguales, retorna true.
    }

    //Buscamos 4 letras iguales de forma HORIZONTAL.
    public static boolean horizontal(ArrayList<ArrayList<String>> arrayMatrixdna) {
        for (ArrayList<String> row : arrayMatrixdna) {
            for (int j = 0; j < row.size() - 3; j++) {
                if (row.get(j).equals(row.get(j + 1)) && row.get(j + 1).equals(row.get(j + 2)) && row.get(j + 2).equals(row.get(j + 3))) {
                    return true;   //Si se cumple la condición que compara hasta la posición [3] de la primer flila (de izq a der) las columnas de la primera fila, la funcion isMutant() va a devolver true.
                } else if (row.get(5).equals(row.get(4)) && row.get(4).equals(row.get(3)) && row.get(3).equals(row.get(2))) {
                    return true;  //Acá hace lo mismo que en el if anteriror pero va comparando los valores de der a izq, hasta la posición [2].
                }
            }
        }
        return false;
    }

    //Buscamos 4 letras iguales de forma VERTICAL
    public static boolean vertical(ArrayList<ArrayList<String>> arrayMatrixdna) {
        for (int j = 0; j < arrayMatrixdna.size() - 3; j++) {
            for (int i = 0; i < arrayMatrixdna.get(0).size(); i++) {
                if (arrayMatrixdna.get(j).get(i).equals(arrayMatrixdna.get(j + 1).get(i)) &&
                        arrayMatrixdna.get(j + 1).get(i).equals(arrayMatrixdna.get(j + 2).get(i)) &&
                        arrayMatrixdna.get(j + 2).get(i).equals(arrayMatrixdna.get(j + 3).get(i))) {
                    return true;
                } else if (arrayMatrixdna.get(5).get(i).equals(arrayMatrixdna.get(4).get(i)) &&
                        arrayMatrixdna.get(4).get(i).equals(arrayMatrixdna.get(3).get(i)) &&
                        arrayMatrixdna.get(3).get(i).equals(arrayMatrixdna.get(2).get(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    //Buscamos 4 letras iguales de forma DIAGONAL
    public static boolean diagonal(ArrayList<ArrayList<String>> arrayMatrixdna) {
        for (int i = 0; i < arrayMatrixdna.size() - 3; i++) {
            for (int j = 0; j < arrayMatrixdna.get(0).size() - 3; j++) {
                if (arrayMatrixdna.get(i).get(j).equals(arrayMatrixdna.get(i + 1).get(j + 1)) &&
                        arrayMatrixdna.get(i + 1).get(j + 1).equals(arrayMatrixdna.get(i + 2).get(j + 2)) &&
                        arrayMatrixdna.get(i + 2).get(j + 2).equals(arrayMatrixdna.get(i + 3).get(j + 3))) {
                    return true;
                } else if (arrayMatrixdna.get(i + 3).get(j + 3).equals(arrayMatrixdna.get(i + 2).get(j + 2)) &&
                        arrayMatrixdna.get(i + 2).get(j + 2).equals(arrayMatrixdna.get(i + 1).get(j + 1)) &&
                        arrayMatrixdna.get(i + 1).get(j + 1).equals(arrayMatrixdna.get(i).get(j))) {
                    return true;
                }
            }
        }
        return false;
    }
}










